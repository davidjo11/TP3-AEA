package tp2.Exercice1.exception;

@SuppressWarnings("serial")
public class VertexAlreadyExistException extends Exception {

}
