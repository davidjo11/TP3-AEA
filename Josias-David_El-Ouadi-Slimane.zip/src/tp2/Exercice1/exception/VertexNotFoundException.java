package tp2.Exercice1.exception;

@SuppressWarnings("serial")
public class VertexNotFoundException extends Exception {

}
