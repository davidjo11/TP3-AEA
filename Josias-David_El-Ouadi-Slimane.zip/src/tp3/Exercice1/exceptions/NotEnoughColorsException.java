package tp3.Exercice1.exceptions;

public class NotEnoughColorsException extends Exception {

}
