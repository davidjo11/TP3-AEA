dot -Tps graph.txt -o graph.ps;
sleep 0.05;
dot -Tps graphPrim.txt -o graphPrim.ps;
sleep 0.05;
dot -Tps graphKruskal.txt -o graphKruskal.ps;
sleep 0.05;
